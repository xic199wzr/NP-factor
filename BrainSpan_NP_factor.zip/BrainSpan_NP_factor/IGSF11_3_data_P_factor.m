

clear;clc
%% merge plot
path ='H:\Open_project\Nature_human_behav_gene-cog-map\hansen_genescognition-master\BrainSpan';
cd(path)
cortex = load('IGSF11_cortex.mat');
subcortex = load('IGSF11_subcortex.mat');

gscore_mat = [cortex.gscore_mat;subcortex.gscore_mat];
Labels = [cortex.labels;subcortex.labels];


%% figures
% change the colourmap if you don't want to download cbrewer
cm=cbrewer('qual', 'Paired', 16, 'PCHIP');

% gene scores across development
figure(1);
for k = 1:size(gscore_mat,1)                                    % for each brain region
    hold on
    plot(gscore_mat(k,:),'LineWidth',1.3,'Color',cm(k,:))  % plot a curve of gene score in that brain region across all five life stages
end
plot(mean(gscore_mat,1),'LineWidth',20)
legend([Labels;'Mean Score'],'Location','northwest');
xticks(1:5)
xticklabels({'fetus','infant','child','adolescent','adult'})
ylabel('IGSF11 scores')



