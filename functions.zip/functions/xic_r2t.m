function t = xic_r2t(r,n)
df = n-2;
t = (r./sqrt((1-power(r,2))))*sqrt(df);